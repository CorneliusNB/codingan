#include<stdio.h>
#include<string.h>
#include<ctype.h>

int main(){
  char string1[201];
  char string2[201];
  scanf("%s", string1); getchar();
  scanf("%s", string2); getchar();

  char res[401];
  int y = 0;
  
  int len1 = strlen(string1);
  int len2 = strlen(string2);
  
  int minlen = len1 < len2 ? len1 : len2;
  for(int i = 0; i < minlen; i++){
    if(string1[i] == string2[i]){
      if(isupper(string1[i])){
        res[y] = tolower(string1[i]);
      } else {
        res[y] = toupper(string1[i]);
      }
      y++;
    } else {
      break;
    }
  }

  int suffixlen = 0;
  int idx1 = len1 - 1;
  int idx2 = len2 - 1;

  while(idx1 >= 0 && idx2 >= 0){
    if(string1[idx1] == string2[idx2]){
      suffixlen++;
      idx1--;
      idx2--;
    } else {
      break;
    }
  }

  for(int i = len1 - suffixlen; i < len1; i++){
    if(isupper(string1[i])){
      res[y] = tolower(string1[i]);
    } else {
      res[y] = toupper(string1[i]);
    }
    y++;
  }

  res[y] = '\0';

  if(y == 0){
    printf("No Output\n");
  } else {
    printf("%s\n", res);
  }

  return 0;
}
